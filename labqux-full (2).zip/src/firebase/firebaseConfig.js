import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCitQuz7S3Yd_Iw48Q8RO9QjGyN5bUSr14",
  authDomain: "labqux.firebaseapp.com",
  projectId: "labqux",
  storageBucket: "labqux.appspot.com",
  messagingSenderId: "988531355697",
  appId: "1:988531355697:web:0955ce6a94926592102510",
  measurementId: "G-1MRPBT4GGF"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();