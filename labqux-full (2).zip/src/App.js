import React from 'react';
import Header from './components/Header';
import CryptoSection from './components/CryptoSection';
import WhaleSection from './components/WhaleSection';
import MetricsSection from './components/MetricsSection';
import NewsSection from './components/NewsSection';
import AIBot from './components/AIBot';

const App = () => {
  return (
    <>
      <Header />
      <CryptoSection />
      <WhaleSection />
      <MetricsSection />
      <NewsSection />
      <AIBot />
    </>
  );
};

export default App;